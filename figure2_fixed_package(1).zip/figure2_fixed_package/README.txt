Figure 2 reconstruction package

figure2a/
  data.json          Aggregated data for subfigure (a): mean / 25th / 75th percentile by decoding step.
  draw_a.py          Reproduces subfigure (a) from data.json.
  figure2a.{png,pdf} Rendered outputs.

figure2b/
  source_original_merge.pdf      Original merged figure used for exact vector reverse extraction.
  extract_b_exact_from_pdf.py    Extracts all 4x8x8 cell fill RGB values directly from PDF vector rectangles and maps them to the embedded colorbar to recover confidence values.
  data.json                      Exact recovered token/step/fill-RGB/confidence data. No masked candidate cells are missing.
  draw_b.py                      Reproduces subfigure (b) from data.json using the exact original cell colors, with enlarged text/legend.
  figure2b.{png,pdf}             Rendered outputs.

merged/
  make_merged.py                 Combines the two PDF subfigures vector-preservingly with embedded (a)/(b) labels.
  figure2_merged_final.{png,pdf} Final merged figure.

Suggested regeneration:
  python figure2a/draw_a.py
  python figure2b/extract_b_exact_from_pdf.py
  python figure2b/draw_b.py
  python merged/make_merged.py
