import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data.json'
OUT_PNG=ROOT/'figure2a.png'
OUT_PDF=ROOT/'figure2a.pdf'

d=json.loads(DATA.read_text())
COLORS={
 'left_to_right':'#E76F51',
 'right_to_left':'#2A7774',
 'confidence_max':'#83A976',
 'random':'#E5BE4E',
 'oracle':'#F4A261',
}
ORDER=['left_to_right','right_to_left','confidence_max','random','oracle']

fig,ax=plt.subplots(figsize=(8.9,6.9),dpi=240)
fig.patch.set_facecolor('white'); ax.set_facecolor('white')
for s in ['top','right']: ax.spines[s].set_visible(False)
for s in ['left','bottom']:
    ax.spines[s].set_color('#555555'); ax.spines[s].set_linewidth(1.1)
ax.grid(True,ls='--',lw=0.75,color='#d7d7d7',alpha=0.85); ax.set_axisbelow(True)

for strat in ORDER:
    x=np.asarray(d[strat]['steps']); y=np.asarray(d[strat]['mean']); q25=np.asarray(d[strat]['q25']); q75=np.asarray(d[strat]['q75'])
    # same tail validity as original code
    counts=np.asarray(d[strat]['counts']); valid=counts>max(1,int(d[strat]['num_traces']*0.01))
    x=x[valid]; y=y[valid]; q25=q25[valid]; q75=q75[valid]
    c=COLORS[strat]
    ax.fill_between(x,q25,q75,color=c,alpha=0.17,lw=0)
    markevery=max(1,len(x)//16)
    ax.plot(x,y,color=c,lw=2.7,marker='o',markersize=4.2,markevery=markevery,label=d[strat]['display_name'])

ax.set_xlim(0,258); ax.set_ylim(0,1.035)
ax.set_yticks(np.linspace(0,1,6))
ax.set_xlabel('Decoding Step',fontsize=19,labelpad=5)
ax.set_ylabel('Avg. Mask Confidence',fontsize=19,labelpad=5)
ax.tick_params(axis='both',labelsize=15,length=4)
ax.text(0.01,1.015,'Shaded band: 25%–75%',transform=ax.transAxes,ha='left',va='bottom',fontsize=13.5,color='#555555')

handles=[Line2D([0],[0],color=COLORS[s],lw=2.7,marker='o',markersize=4.2,label=d[s]['display_name']) for s in ORDER]
leg=ax.legend(handles=handles,ncol=2,loc='upper center',bbox_to_anchor=(0.5,-0.16),fontsize=14.2,
              frameon=True,columnspacing=1.9,handlelength=2.1,handletextpad=0.7,borderpad=0.7)
leg.get_frame().set_facecolor('white'); leg.get_frame().set_edgecolor('#cccccc')
fig.subplots_adjust(left=0.14,right=0.985,top=0.955,bottom=0.25)
fig.savefig(OUT_PNG,bbox_inches='tight',pad_inches=0.02)
fig.savefig(OUT_PDF,bbox_inches='tight',pad_inches=0.02)
print(OUT_PNG); print(OUT_PDF)
