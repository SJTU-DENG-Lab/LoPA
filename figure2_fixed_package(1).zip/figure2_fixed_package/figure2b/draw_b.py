import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data.json'
OUT_PNG=ROOT/'figure2b.png'
OUT_PDF=ROOT/'figure2b.pdf'

d=json.loads(DATA.read_text())
order=['High-Confidence-First','Left to Right','Random','Naive Lookahead']
BLUE='#0000ff'
GREY='#6f6f6f'

fig=plt.figure(figsize=(15.8,9.6),dpi=240)
gs=fig.add_gridspec(3,2,height_ratios=[1,1,0.42],hspace=0.42,wspace=0.08)
axes={
    order[0]:fig.add_subplot(gs[0,0]),
    order[1]:fig.add_subplot(gs[0,1]),
    order[2]:fig.add_subplot(gs[1,0]),
    order[3]:fig.add_subplot(gs[1,1]),
}

for idx,title in enumerate(order):
    ax=axes[title]
    cells=d['panels'][title]['cells']
    # exact vector colors from original PDF
    for r,row in enumerate(cells):
        for c,cell in enumerate(row):
            rgb=cell['fill_rgb']
            ax.add_patch(Rectangle((c+0.5,r+0.5),1,1,facecolor=rgb,edgecolor=(0.92,0.92,0.92),lw=0.45,zorder=1))
            if cell['current_step']:
                ax.add_patch(Rectangle((c+0.5,r+0.5),1,1,facecolor='none',edgecolor=BLUE,lw=1.3,zorder=3))
            if cell['current_step'] or cell['already_decoded']:
                token=cell['token']
                if token == 'breakfast':
                    fs = 11.6
                elif len(token) >= 9:
                    fs = 13.6
                elif len(token) >= 6:
                    fs = 16.8
                elif len(token) >= 4:
                    fs = 19.8
                else:
                    fs = 21.0
                if cell['current_step']:
                    ax.text(c+1,r+1,token,ha='center',va='center',fontsize=fs,fontweight='bold',color='black',zorder=4)
                else:
                    ax.text(c+1,r+1,token,ha='center',va='center',fontsize=fs-1.4,color=GREY,zorder=4)
    ax.set_xlim(0.5,8.5); ax.set_ylim(8.5,0.5)
    ax.set_aspect('auto')
    ax.set_title(title,fontsize=19.0,fontweight='bold',pad=7)
    ax.set_xticks(range(1,9)); ax.set_yticks(range(1,9))
    ax.set_yticklabels([f'Step {i}' for i in range(8)],fontsize=13.0)
    ax.tick_params(axis='x',labelsize=11.5,length=2.5)
    ax.tick_params(axis='y',length=2.5)
    for s in ax.spines.values(): s.set_visible(False)

# Match original labeling density.
axes[order[1]].set_yticklabels([])
axes[order[3]].set_yticklabels([])
axes[order[0]].set_xticklabels([])
axes[order[1]].set_xticklabels([])
axes[order[0]].set_ylabel('Decoding Step',fontsize=16.5,fontweight='bold')
axes[order[2]].set_ylabel('Decoding Step',fontsize=16.5,fontweight='bold')
axes[order[2]].set_xlabel('Token Position',fontsize=16.5,fontweight='bold',labelpad=4)
axes[order[3]].set_xlabel('Token Position',fontsize=16.5,fontweight='bold',labelpad=4)

# Bottom: large legend + exact original colorbar pixels.
bottom=gs[2,:].subgridspec(1,2,wspace=0.14,width_ratios=[1,1])
leg_ax=fig.add_subplot(bottom[0,0]); leg_ax.axis('off')
# exact original representative masked candidate color from confidence about 0.35
bar_rgb=np.asarray(d['colorbar_rgb'])
masked_rgb=bar_rgb[int(0.35*(len(bar_rgb)-1))]
handles=[
    Patch(facecolor=(0.91008,0.91022,0.91005),edgecolor='none',label='Already Decoded'),
    Patch(facecolor='none',edgecolor=BLUE,linewidth=1.7,label='Current Step'),
    Patch(facecolor=masked_rgb,edgecolor='none',label='Masked Candidate'),
]
leg=leg_ax.legend(handles=handles,ncol=3,loc='center',frameon=True,title='Legend',
                  fontsize=16.0,title_fontsize=18.5,handlelength=2.0,columnspacing=2.5,
                  handletextpad=0.8,borderpad=0.8,labelspacing=0.8)
leg.get_title().set_fontweight('bold')

cb_outer=fig.add_subplot(bottom[0,1])
cb_outer.axis('off')
cb_outer.text(0.5,0.88,'Confidence Predicted by Model',ha='center',va='center',fontsize=17.0,fontweight='bold')
cb_ax=cb_outer.inset_axes([0.04,0.24,0.92,0.22])
grad=bar_rgb[None,:,:]
cb_ax.imshow(grad,aspect='auto',extent=[0,1,0,1],interpolation='nearest')
cb_ax.set_yticks([])
cb_ax.set_xticks(np.linspace(0,1,6))
cb_ax.tick_params(axis='x',labelsize=14.0,length=3)
for s in cb_ax.spines.values():
    s.set_visible(True); s.set_linewidth(0.8); s.set_color('black')

fig.patch.set_facecolor('white')
fig.subplots_adjust(left=0.055,right=0.985,top=0.96,bottom=0.055)
fig.savefig(OUT_PNG,bbox_inches='tight',pad_inches=0.02)
fig.savefig(OUT_PDF,bbox_inches='tight',pad_inches=0.02)
print(OUT_PNG); print(OUT_PDF)
