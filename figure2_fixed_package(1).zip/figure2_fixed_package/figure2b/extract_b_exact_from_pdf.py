import fitz, json
import numpy as np
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PDF = ROOT/'source_original_merge.pdf'
OUT = ROOT/'data.json'

PANEL_INFO = {
    'High-Confidence-First': {'x_group':0,'y_group':0,'tokens':['Janet','eats','↵','3','eggs','for','breakfast','and'],'selected':[0,2,1,3,4,5,6,7]},
    'Left to Right': {'x_group':1,'y_group':0,'tokens':['Janet','eats','↵','3','eggs','for','breakfast','and'],'selected':[0,1,2,3,4,5,6,7]},
    'Random': {'x_group':0,'y_group':1,'tokens':['Janet','eats','and','uses','↵','3','+','↵'],'selected':[7,5,0,2,6,3,1,4]},
    'Naive Lookahead': {'x_group':1,'y_group':1,'tokens':['Janet',"'s",'ducks','lay','↵','1','6','eggs'],'selected':[1,6,3,7,0,2,4,5]},
}
GREY = np.array([0.9100785851,0.9102159142,0.9100480676])

doc = fitz.open(PDF)
page = doc[0]

# Exact colorbar image embedded in the original PDF.
img_info = page.get_images(full=True)[0]
xref = img_info[0]
pix = fitz.Pixmap(doc, xref)
bar = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height,pix.width,pix.n)[...,:3] / 255.0
bar_rgb = np.median(bar, axis=0)
bar_vals = np.linspace(0,1,bar_rgb.shape[0])

def confidence_from_rgb(rgb):
    rgb=np.asarray(rgb)
    idx=int(np.argmin(np.sum((bar_rgb-rgb[None,:])**2,axis=1)))
    return float(bar_vals[idx])

# Pull the 256 exact vector rectangle fills: 4 panels x 8 x 8.
rects=[]
for d in page.get_drawings():
    fill=d.get('fill')
    if fill is None: continue
    for item in d['items']:
        if item[0] != 're': continue
        r=item[1]
        if r.x0>1200 and 90<r.width<100 and 34<r.height<37:
            rects.append({
                'x0':float(r.x0),'y0':float(r.y0),'x1':float(r.x1),'y1':float(r.y1),
                'fill_rgb':[float(v) for v in fill],
                'edge_rgb': None if d.get('color') is None else [float(v) for v in d.get('color')],
                'edge_width':float(d.get('width') or 0),
            })
assert len(rects)==256, len(rects)

# Exact grid coordinates extracted from the vector rectangles.
xs=sorted(set(round(r['x0'],5) for r in rects))
ys=sorted(set(round(r['y0'],5) for r in rects))
left_x=xs[:8]; right_x=xs[8:]
top_y=ys[:8]; bottom_y=ys[8:]

out={'source_pdf':str(PDF),'colorbar_rgb':bar_rgb.tolist(),'panels':{}}
for title,info in PANEL_INFO.items():
    xset=left_x if info['x_group']==0 else right_x
    yset=top_y if info['y_group']==0 else bottom_y
    cells=[]
    for ri,y in enumerate(yset):
        row=[]
        for ci,x in enumerate(xset):
            cand=min(rects, key=lambda r: abs(r['x0']-x)+abs(r['y0']-y))
            rgb=np.array(cand['fill_rgb'])
            decoded=np.linalg.norm(rgb-GREY)<0.01
            current=(info['selected'][ri]==ci)
            conf=None if decoded else confidence_from_rgb(rgb)
            row.append({
                'step':ri,
                'token_position':ci+1,
                'token':info['tokens'][ci],
                'fill_rgb':[round(float(v),7) for v in rgb],
                'confidence':None if conf is None else round(conf,4),
                'already_decoded':bool(decoded),
                'current_step':bool(current),
                'edge_rgb':cand['edge_rgb'],
                'edge_width':cand['edge_width'],
            })
        cells.append(row)
    out['panels'][title]={'tokens':info['tokens'],'selected_columns_0based':info['selected'],'cells':cells}

OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False))
print(OUT)
