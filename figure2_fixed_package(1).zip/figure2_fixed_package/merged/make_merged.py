from pathlib import Path
import fitz

ROOT=Path(__file__).resolve().parent.parent
A=ROOT/'figure2a'/'figure2a.pdf'
B=ROOT/'figure2b'/'figure2b.pdf'
OUT=Path(__file__).resolve().parent/'figure2_merged_final.pdf'
PNG=Path(__file__).resolve().parent/'figure2_merged_final.png'
GAP=18.0
LABEL_H=34.0
FONTFILE='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

adoc=fitz.open(A); bdoc=fitz.open(B)
ar=adoc[0].rect; br=bdoc[0].rect
target_h=ar.height
b_scale=target_h/br.height
bw=br.width*b_scale
page_w=ar.width+GAP+bw
page_h=target_h+LABEL_H

out=fitz.open(); p=out.new_page(width=page_w,height=page_h)
a_rect=fitz.Rect(0,0,ar.width,target_h)
b_rect=fitz.Rect(ar.width+GAP,0,ar.width+GAP+bw,target_h)
p.show_pdf_page(a_rect,adoc,0,keep_proportion=True)
p.show_pdf_page(b_rect,bdoc,0,keep_proportion=True)

font=fitz.Font(fontfile=FONTFILE)
p.insert_font(fontname='DJVB',fontfile=FONTFILE)
fontsize=18
for label,rect in [('(a)',a_rect),('(b)',b_rect)]:
    tw=font.text_length(label,fontsize=fontsize)
    x=(rect.x0+rect.x1-tw)/2
    y=target_h+24
    p.insert_text((x,y),label,fontname='DJVB',fontsize=fontsize,color=(0,0,0))

out.save(OUT,garbage=4,deflate=True)
out.close(); adoc.close(); bdoc.close()
# render preview
rdoc=fitz.open(OUT); pix=rdoc[0].get_pixmap(matrix=fitz.Matrix(2.2,2.2),alpha=False); pix.save(PNG); rdoc.close()
print(OUT); print(PNG)
